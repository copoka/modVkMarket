--------------------
modVkMarket
--------------------
Author: John Doe <john@doe.com>
--------------------

A basic Extra for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/username/modVkMarket/issues