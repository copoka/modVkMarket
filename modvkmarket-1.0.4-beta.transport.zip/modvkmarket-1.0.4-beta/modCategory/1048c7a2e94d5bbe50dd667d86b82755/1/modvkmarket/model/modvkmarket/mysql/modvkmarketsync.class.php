<?php
require_once (dirname(dirname(__FILE__)) . '/modvkmarketsync.class.php');
class modVkMarketSync_mysql extends modVkMarketSync {}