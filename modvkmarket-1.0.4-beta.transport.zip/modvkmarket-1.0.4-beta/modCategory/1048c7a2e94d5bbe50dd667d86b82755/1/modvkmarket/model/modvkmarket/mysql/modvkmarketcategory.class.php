<?php
require_once (dirname(dirname(__FILE__)) . '/modvkmarketcategory.class.php');
class modVkMarketCategory_mysql extends modVkMarketCategory {}