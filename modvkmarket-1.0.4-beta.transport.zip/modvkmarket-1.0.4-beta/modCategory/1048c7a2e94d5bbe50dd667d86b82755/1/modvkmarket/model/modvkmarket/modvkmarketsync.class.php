<?php
class modVkMarketSync extends xPDOSimpleObject {}