<?php
class modVkMarketCategory extends xPDOSimpleObject {}