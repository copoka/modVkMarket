<?php
include_once 'setting.inc.php';
include_once 'manager.inc.php';

$_lang['modvkmarket'] = 'modVkMarket';
$_lang['modvkmarket_menu_desc'] = 'Управление маркетом VK.';
$_lang['modvkmarket_goods'] = 'Товары';
$_lang['modvkmarket_categories'] = 'Категории';
$_lang['modvkmarket_goods_intro_msg'] = 'Управление товарами';
$_lang['modvkmarket_categories_intro_msg'] = 'Управление категориями';

$_lang['modvkmarket_good'] = 'Товар';
$_lang['modvkmarket_category'] = 'Категория';

